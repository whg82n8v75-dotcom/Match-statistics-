BASKET MATCH APP

Versione mobile per uso durante la partita.

Funzioni:
- tabellone Home/Away
- punteggio +1/+2/+3
- cronometro e quarti
- 5 in campo selezionabili
- statistiche rapide per giocatore: FG, 3PT, FT, TO, RO, RD, AST, PF
- rosa con numero e nome
- storico degli eventi
- salvataggio locale
- esportazione CSV
- stampa

Uso:
1. Aprire index.html in un browser.
2. Su iPhone/iPad, se l'app è pubblicata su un sito HTTPS, usare Condividi > Aggiungi alla schermata Home per installarla come app.
